package restAPI;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetRequest {
    
    @Test
    public void GetCall() {
    	Logger logger= Logger.getLogger("EmployeeLogs");
    	PropertyConfigurator.configure("log4j.properties");
    	logger.setLevel(Level.DEBUG);
    	logger.info("**********Start the getcall*******");
      
        
        RestAssured.baseURI = "http://52.90.186.211:8088/employees";
        
        RequestSpecification request = RestAssured.given();
        
        Response response = request.get("/employees");
        
        String ResponseBody = response.getBody().asString();
        
        System.out.println(ResponseBody);
        
    }
}