package restAPI;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import io.restassured.specification.RequestSpecification;

public class GetRequestwithParams { public ResponseOptions<Response> response;

public class GetRequest {
    
    @Test
	public void GetCall() {
        
        RestAssured.baseURI = "http://localhost:7000";
        
        RequestSpecification request = RestAssured.given();
        
        Response response = request.param("id","1").get("/employees");
        
        String ResponseBody = response.getBody().asString();
        
        System.out.println(ResponseBody);
        
    }
    //=============verify the response code===========
    //int ResCode=response.getStatuscode();
  //  Assert.assertEquals(ResCode,200);
    //======================verify response header=======
    String ResponseHeader=response.getHeader("content-Type");

    
   //System.out.println("Response Header:"+ResponseHeader);
    
    //System.out.println("All Header"+response.getHeaders());
    //Assert.assertEquals(ResponseHeader,"application/json charset=utf-8");
    //=========verify response body==
    
   // Assert.assertTrue(ResponseBody.contains("pankaj"));
    //JsonPathjpath=response.jsonPath();
    //List<String>names=jpath.get("name");
    //Assert.assertEquals(names.get(0),"Pankaj");
    
    
   
}


}
