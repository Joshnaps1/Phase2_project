package restAPIChaining;

import org.testng.annotations.Test;
import java.util.List;

import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class EndToEndTest {
	
	@Test
	public void Test1() {
		
		String ResponseBody;
		String ResponseId;
		
		RestAssured.baseURI = "http://localhost:7000";
		
		//============ Get Call ===========
		
		RequestSpecification GetRequest = RestAssured.given();
		Response GetResponse = GetRequest.get("/employees");
		ResponseBody = GetResponse.getBody().asString();
		System.out.println(ResponseBody);
		
		//============== Post Call ====================
		
		RequestSpecification PostRequest = RestAssured.given();
		
		JSONObject jobj = new JSONObject();
		jobj.put("name", "Chris");
		jobj.put("salary", "5000");
		
		Response PostResponse = PostRequest.contentType(ContentType.JSON)
						.accept(ContentType.JSON)
						.body(jobj.toString())
						.post("/employees/create");
		
		ResponseBody = PostResponse.getBody().asString();
		System.out.println(ResponseBody);
		
		JsonPath jpath = PostResponse.jsonPath();
		ResponseId = jpath.get("id").toString();
		System.out.println("Id Coming from Reponse is " + ResponseId );
		
		//============= Put Call ==================
		
		RequestSpecification PutRequest = RestAssured.given();
		
		jobj.put("name", "Chris1");
		jobj.put("salary", "5000");
		
		Response PutResponse = PutRequest.contentType(ContentType.JSON)
						.accept(ContentType.JSON)
						.body(jobj.toString())
						.put("/employees/" + ResponseId);
		
		ResponseBody = PutResponse.getBody().asString();
		System.out.println(ResponseBody);
		
		
		//============ Delete Call ==================
		
		RequestSpecification DeleteRequest = RestAssured.given();
		Response DeleteResponse = DeleteRequest.delete("/employees/" + ResponseId);
		ResponseBody = DeleteResponse.getBody().asString();
		System.out.println(ResponseBody);
	}

}


